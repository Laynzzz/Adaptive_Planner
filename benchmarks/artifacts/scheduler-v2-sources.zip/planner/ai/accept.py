"""Apply only the selected, explicitly reviewed task fields in one command transaction."""

import json
from uuid import uuid5

from pydantic import ValidationError
from sqlalchemy import func, select

from planner.ai.interpret import parse_proposal
from planner.api.errors import APIError
from planner.api.schemas import TaskFields
from planner.db.ai_models import InterpretationRecord
from planner.db.models import DependencyEdge, Task
from planner.domain.time_rules import normalize_time_inputs


def accept_in_transaction(
    db, owner_id, interpretation_id, selected_keys, confirmed_fields, overrides, *, now
):
    record = db.scalar(
        select(InterpretationRecord).where(
            InterpretationRecord.id == interpretation_id, InterpretationRecord.owner_id == owner_id
        )
    )
    if record is None:
        raise APIError("NOT_FOUND", 404, "Interpretation not found.")
    if record.state != "READY":
        raise APIError(
            "INTERPRETATION_NOT_READY", 409, "Review a ready interpretation before accepting it."
        )
    try:
        proposal = parse_proposal(json.dumps(record.proposal), record.source_text)
    except (ValueError, KeyError):
        raise APIError(
            "MODEL_OUTPUT_INVALID", 422, "The proposal failed semantic validation."
        ) from None
    if proposal.constraints:
        raise APIError(
            "CONSTRAINT_EDITOR_REQUIRED",
            422,
            "Weekday rules require manual constraint editing; no rule was applied.",
        )
    if proposal.abstained or not selected_keys:
        raise APIError(
            "CLARIFICATION_REQUIRED", 422, "Select and clarify at least one proposed task."
        )
    tasks = {task.key: task for task in proposal.tasks}
    selected = set(selected_keys)
    if len(selected) != len(selected_keys) or not selected.issubset(tasks):
        raise APIError("SELECTION_INVALID", 422, "Select only proposed task keys, once each.")
    allowed = {
        f"tasks.{key}.{field}"
        for key in selected
        for field in ("title", "remaining_minutes", "deadline", "priority")
    }
    if not set(overrides).issubset(allowed) or not set(confirmed_fields).issubset(allowed):
        raise APIError(
            "REVIEW_FIELDS_INVALID", 422, "Review fields must refer to selected proposed tasks."
        )
    all_paths = {
        f"tasks.{key}.{name}"
        for key in tasks
        for name in ("title", "remaining_minutes", "deadline", "priority")
    }
    for path in proposal.unresolved_fields:
        if path not in all_paths or (path in allowed and path not in overrides):
            raise APIError(
                "CLARIFICATION_REQUIRED",
                422,
                "Resolve the proposal's contradictions and selected unknown fields.",
            )
    count = db.scalar(
        select(func.count())
        .select_from(Task)
        .where(Task.owner_id == owner_id, Task.state.notin_(["DONE", "CANCELLED"]))
    )
    if count + len(selected) > 200:
        raise APIError("ACTIVE_TASK_LIMIT", 422, "At most 200 active tasks are supported.")
    resolved = []
    ids = {key: uuid5(record.id, key) for key in selected}
    for key in selected_keys:
        task = tasks[key]
        if not set(task.predecessor_keys).issubset(selected):
            raise APIError(
                "DEPENDENCY_SELECTION_REQUIRED", 422, "Select all referenced predecessors."
            )
        fields = {}
        for name in ("title", "remaining_minutes", "deadline", "priority"):
            extracted = getattr(task, name)
            path = f"tasks.{key}.{name}"
            if path in overrides:
                value = overrides[path]
            elif extracted.label == "unknown":
                raise APIError(
                    "CLARIFICATION_REQUIRED", 422, "Resolve every unknown selected field."
                )
            elif extracted.requires_confirmation and path not in confirmed_fields:
                raise APIError(
                    "CONFIRMATION_REQUIRED", 422, "Confirm each inferred selected field."
                )
            else:
                value = (
                    extracted.value.model_dump(mode="json")
                    if hasattr(extracted.value, "model_dump")
                    else extracted.value
                )
            fields[name] = value
        try:
            parsed = TaskFields.model_validate(fields)
            data = parsed.model_dump(mode="json")
            normalize_time_inputs(
                {
                    "owner_id": str(owner_id),
                    "timezone": record.timezone,
                    "tasks": [{"id": str(ids[key]), **data}],
                },
                now,
            )
        except (ValueError, KeyError, OverflowError, ValidationError):
            raise APIError(
                "REVIEW_VALUE_INVALID", 422, "The reviewed task values are invalid."
            ) from None
        resolved.append((key, data))
    for key, data in resolved:
        db.add(
            Task(
                id=ids[key],
                owner_id=owner_id,
                title=data["title"],
                remaining_minutes=data["remaining_minutes"],
                priority=data["priority"],
                state="TODO",
                details={
                    k: v
                    for k, v in data.items()
                    if k not in ("title", "remaining_minutes", "priority")
                },
            )
        )
    db.flush()
    for key in selected_keys:
        for predecessor in tasks[key].predecessor_keys:
            db.add(
                DependencyEdge(
                    owner_id=owner_id, predecessor_id=ids[predecessor], successor_id=ids[key]
                )
            )
    record.state = "ACCEPTED"
    record.accepted_task_ids = [str(ids[key]) for key in selected_keys]
    return {"task_ids": record.accepted_task_ids, "interpretation_id": str(record.id)}
